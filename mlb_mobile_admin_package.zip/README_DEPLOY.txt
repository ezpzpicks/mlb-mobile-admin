MLB Mobile Admin Website - Deployment Notes

Files included:
- app_mobile_admin.py
- requirements.txt
- .streamlit/config.toml

Local test:
1. Put app_mobile_admin.py and requirements.txt in a new folder.
2. Install requirements:
   pip install -r requirements.txt
3. Run:
   streamlit run app_mobile_admin.py
4. If you have not set a password secret yet, use the temporary local password: admin

Render deployment:
1. Create a new GitHub repo.
2. Upload app_mobile_admin.py, requirements.txt, and the .streamlit folder.
3. Create a new Render Web Service connected to that repo.
4. Runtime: Python.
5. Build command:
   pip install -r requirements.txt
6. Start command:
   streamlit run app_mobile_admin.py --server.port $PORT --server.address 0.0.0.0
7. Add environment variable:
   ADMIN_PASSWORD = your private password
8. Deploy.

Important:
- This first mobile/admin version still uses CSV files for daily_slate.csv and bet_tracker.csv.
- That is fine for testing, but on hosted Render the files may not be reliable long-term.
- The next upgrade should move slate/tracker storage to Google Sheets or Supabase.

Current workflow:
- Upload your current MLB Excel workbook from phone or PC.
- App pulls today's MLB schedule/probable pitchers.
- You manually enter lines/odds.
- Save matchups, update results, view ROI/record summary.
